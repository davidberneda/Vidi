Vidi Language
Pre-Release v.0.0.18-alpha  June-2021
-------------------------------------

Web: http://vidi.dev

GitHub: https://github.com/davidberneda/Vidi
Twitter: https://twitter.com/Vidi_Lang

Includes:

- Simple ide (Vidi.exe) and command line compiler (VidiCLI.exe) 
- For Windows 32bit, 64bit and Linux 64bit
- Demos (small code snippets)
- Language Reference document (pdf)

Pending:

- Transpilers are in a "proof of concept" state, not yet ready
- Interpreter runs most of the test examples, but not all of them

Compiled with: https://www.freepascal.org
